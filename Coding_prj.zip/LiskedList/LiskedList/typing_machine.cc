// Copyright 2018 <Author>

#include "typing_machine.h"

TypingMachine::TypingMachine() {
  return;
}

void TypingMachine::HomeKey() {
  return;
}

void TypingMachine::EndKey() {
  return;
}

void TypingMachine::LeftKey() {
  return;
}

void TypingMachine::RightKey() {
  return;
}

bool TypingMachine::TypeKey(char key) {
  return false;
}

bool TypingMachine::EraseKey() {
  return false;
}

std::string TypingMachine::Print(char separator) {
  return "";
}
