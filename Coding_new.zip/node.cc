// Copyright 2018 <Author>

#include "node.h"

Node::Node(char data) {
  return;
}

char Node::GetData() {
  return '\0';
}

Node* Node::GetPreviousNode() {
  return nullptr;
}

Node* Node::GetNextNode() {
  return nullptr;
}

Node* Node::InsertPreviousNode(char data) {
  return nullptr;
}

Node* Node::InsertNextNode(char data) {
  return nullptr;
}

bool Node::ErasePreviousNode() {
  return false;
}

bool Node::EraseNextNode() {
  return false;
}
